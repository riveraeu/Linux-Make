//  Created by Eugene Rivera on 11/20/15.


#include "TreeNode.hpp"

TreeNode::TreeNode(GraphNode *nNode){
    makeNode = nNode;
    leftSubtree = nullptr;
    rightSubtree = nullptr;
}

